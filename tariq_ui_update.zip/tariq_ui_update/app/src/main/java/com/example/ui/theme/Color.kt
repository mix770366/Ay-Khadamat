package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Colors - طارق الزنم (الأسود والذهبي الفاخر)
val GoldPrimary = Color(0xFFF5B800)
val GoldLight = Color(0xFFFFD54F)
val GoldDark = Color(0xFFC68A00)
val GoldBorder = Color(0xFFD4AF37)
val ObsidianBlack = Color(0xFF0D0D0D)
val CharcoalSurface = Color(0xFF1A1A1A)
val CharcoalVariant = Color(0xFF242424)
val DarkGoldContainer = Color(0xFF2B2208)

// Mapped aliases for full compatibility across all existing screens
val EmeraldGreenPrimary = GoldPrimary
val EmeraldGreenLight = GoldLight
val EmeraldGreenDark = GoldLight
val EmeraldGreenContainer = DarkGoldContainer
val OnEmeraldGreenContainer = GoldLight

val AmberAccentSecondary = GoldPrimary
val AmberAccentContainer = DarkGoldContainer
val OnAmberAccentContainer = GoldLight

val TrustBlueTertiary = Color(0xFF38BDF8)
val TrustBlueContainer = Color(0xFF0C2438)
val OnTrustBlueContainer = Color(0xFFBAE6FD)

val MintBackgroundLight = ObsidianBlack
val CardSurfaceLight = CharcoalSurface
val SurfaceVariantLight = CharcoalVariant
val OutlineLight = Color(0xFF4A3C18)

// Dark Palette
val EmeraldGreenDarkPrimary = GoldPrimary
val EmeraldGreenDarkContainer = DarkGoldContainer
val AmberAccentDarkSecondary = GoldLight
val DarkBackground = ObsidianBlack
val DarkSurface = CharcoalSurface
val DarkSurfaceVariant = CharcoalVariant
val DarkOutline = Color(0xFF4A3C18)

// Guarantee badge colors
val GoldGuarantee = GoldPrimary
val RedUrgent = Color(0xFFEF4444)
val BlueShield = Color(0xFF38BDF8)
val PurpleVip = Color(0xFFA855F7)
