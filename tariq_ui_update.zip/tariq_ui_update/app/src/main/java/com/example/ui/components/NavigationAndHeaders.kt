package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.outlined.Category
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.Screen
import com.example.ui.theme.CharcoalSurface
import com.example.ui.theme.DarkGoldContainer
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.ObsidianBlack

@Composable
fun AyTopAppBar(
    currentDistrict: String,
    cartItemCount: Int,
    onDistrictClick: () -> Unit,
    onCartClick: () -> Unit,
    onGuaranteeClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = ObsidianBlack,
        tonalElevation = 0.dp,
        shadowElevation = 4.dp
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Brand Logo & Title
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(ObsidianBlack)
                            .border(1.dp, GoldBorder.copy(alpha = 0.7f), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.mipmap.ic_launcher),
                            contentDescription = "طارق الزنم",
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(10.dp)),
                            contentScale = ContentScale.Crop
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "طارق الزنم",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 19.sp,
                                    color = GoldPrimary
                                )
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(DarkGoldContainer)
                                    .border(0.5.dp, GoldBorder.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "محافظة إب",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GoldLight
                                )
                            }
                        }

                        // Neighborhood Selector
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onDistrictClick() }
                                .padding(vertical = 2.dp)
                                .testTag("select_district_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocationOn,
                                contentDescription = "الموقع",
                                tint = GoldPrimary,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = currentDistrict,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color(0xFFE0E0E0)
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Icon(
                                imageVector = Icons.Default.KeyboardArrowDown,
                                contentDescription = "تغيير",
                                tint = GoldLight,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                // Guarantee Shield Button & Cart Icon
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                        border = BorderStroke(1.dp, GoldBorder.copy(alpha = 0.45f)),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier
                            .clickable { onGuaranteeClick() }
                            .padding(end = 6.dp)
                            .testTag("guarantee_badge_header")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.VerifiedUser,
                                contentDescription = "ضمان",
                                tint = GoldPrimary,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "ضماننا",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = GoldLight
                            )
                        }
                    }

                    IconButton(
                        onClick = onCartClick,
                        modifier = Modifier
                            .size(42.dp)
                            .testTag("cart_icon_button")
                    ) {
                        BadgedBox(
                            badge = {
                                if (cartItemCount > 0) {
                                    Badge(
                                        containerColor = GoldPrimary,
                                        contentColor = ObsidianBlack
                                    ) {
                                        Text(
                                            text = cartItemCount.toString(),
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.ShoppingCart,
                                contentDescription = "سلة الطلبات",
                                tint = GoldPrimary,
                                modifier = Modifier.size(23.dp)
                            )
                        }
                    }
                }
            }
            HorizontalDivider(thickness = 0.8.dp, color = GoldBorder.copy(alpha = 0.25f))
        }
    }
}

@Composable
fun AyBottomBar(
    currentScreen: Screen,
    activeOrdersCount: Int,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        HorizontalDivider(thickness = 0.8.dp, color = GoldBorder.copy(alpha = 0.25f))
        NavigationBar(
            containerColor = ObsidianBlack,
            tonalElevation = 0.dp
        ) {
            val navColors = NavigationBarItemDefaults.colors(
                selectedIconColor = GoldPrimary,
                selectedTextColor = GoldPrimary,
                unselectedIconColor = Color(0xFF9E9E9E),
                unselectedTextColor = Color(0xFF9E9E9E),
                indicatorColor = DarkGoldContainer
            )

            // 1. Home
            NavigationBarItem(
                selected = currentScreen == Screen.HOME,
                onClick = { onNavigate(Screen.HOME) },
                icon = {
                    Icon(
                        imageVector = if (currentScreen == Screen.HOME) Icons.Filled.Home else Icons.Outlined.Home,
                        contentDescription = "الرئيسية"
                    )
                },
                label = { Text("الرئيسية", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                colors = navColors,
                modifier = Modifier.testTag("nav_home")
            )

            // 2. Services List
            NavigationBarItem(
                selected = currentScreen == Screen.SERVICES_LIST,
                onClick = { onNavigate(Screen.SERVICES_LIST) },
                icon = {
                    Icon(
                        imageVector = if (currentScreen == Screen.SERVICES_LIST) Icons.Filled.Category else Icons.Outlined.Category,
                        contentDescription = "الأقسام"
                    )
                },
                label = { Text("الأقسام", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                colors = navColors,
                modifier = Modifier.testTag("nav_services")
            )

            // 3. Highlighted Custom Order
            NavigationBarItem(
                selected = currentScreen == Screen.CUSTOM_ORDER,
                onClick = { onNavigate(Screen.CUSTOM_ORDER) },
                icon = {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(Brush.linearGradient(listOf(GoldPrimary, GoldDark))),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddCircle,
                            contentDescription = "اطلب أي شيء",
                            tint = ObsidianBlack,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                },
                label = {
                    Text(
                        "اطلب الآن",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldPrimary
                    )
                },
                colors = navColors,
                modifier = Modifier.testTag("nav_custom_order")
            )

            // 4. Orders
            NavigationBarItem(
                selected = currentScreen == Screen.ORDERS || currentScreen == Screen.ORDER_TRACKING,
                onClick = { onNavigate(Screen.ORDERS) },
                icon = {
                    BadgedBox(
                        badge = {
                            if (activeOrdersCount > 0) {
                                Badge(
                                    containerColor = GoldPrimary,
                                    contentColor = ObsidianBlack
                                ) {
                                    Text(activeOrdersCount.toString(), fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    ) {
                        Icon(
                            imageVector = if (currentScreen == Screen.ORDERS || currentScreen == Screen.ORDER_TRACKING)
                                Icons.Filled.ReceiptLong else Icons.Outlined.ReceiptLong,
                            contentDescription = "طلباتي"
                        )
                    }
                },
                label = { Text("طلباتي", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                colors = navColors,
                modifier = Modifier.testTag("nav_orders")
            )

            // 5. Guarantee Info
            NavigationBarItem(
                selected = currentScreen == Screen.GUARANTEE_INFO,
                onClick = { onNavigate(Screen.GUARANTEE_INFO) },
                icon = {
                    Icon(
                        imageVector = if (currentScreen == Screen.GUARANTEE_INFO) Icons.Filled.Security else Icons.Outlined.Security,
                        contentDescription = "ضماننا"
                    )
                },
                label = { Text("ضماننا", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                colors = navColors,
                modifier = Modifier.testTag("nav_guarantee")
            )
        }
    }
}
