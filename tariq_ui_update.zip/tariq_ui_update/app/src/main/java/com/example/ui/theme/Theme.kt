package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val BlackGoldColorScheme = darkColorScheme(
    primary = GoldPrimary,
    onPrimary = ObsidianBlack,
    primaryContainer = DarkGoldContainer,
    onPrimaryContainer = GoldLight,
    secondary = GoldLight,
    onSecondary = ObsidianBlack,
    secondaryContainer = DarkGoldContainer,
    onSecondaryContainer = GoldLight,
    tertiary = TrustBlueTertiary,
    onTertiary = ObsidianBlack,
    background = ObsidianBlack,
    surface = CharcoalSurface,
    surfaceVariant = CharcoalVariant,
    onBackground = Color(0xFFF5F5F5),
    onSurface = Color(0xFFF5F5F5),
    onSurfaceVariant = Color(0xFFBDBDBD),
    outline = DarkOutline
)

@Composable
fun AyKhadamatTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = BlackGoldColorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    AyKhadamatTheme(darkTheme = darkTheme, dynamicColor = dynamicColor, content = content)
}
